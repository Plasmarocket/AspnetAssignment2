﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AspnetAssignment2.Models
{
    public partial class ApAssignment2Context : DbContext
    {
        public ApAssignment2Context()
        {
        }

        public ApAssignment2Context(DbContextOptions<ApAssignment2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Games> Games { get; set; }
        public virtual DbSet<Payments> Payments { get; set; }
        public virtual DbSet<Store> Store { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=MSI;Database=ApAssignment2;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustomerName);

                entity.Property(e => e.CustomerName)
                    .HasColumnName("customerName")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.BillingAddress)
                    .HasColumnName("billingAddress")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.CardNum).HasColumnName("cardNum");

                entity.Property(e => e.CustomerEmail)
                    .HasColumnName("customerEmail")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.CustomerPhone)
                    .HasColumnName("customerPhone")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.EmpNum)
                    .HasColumnName("empNum")
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmpNum);

                entity.Property(e => e.EmpNum)
                    .HasColumnName("empNum")
                    .ValueGeneratedNever();

                entity.Property(e => e.CheckoutDate)
                    .HasColumnName("checkoutDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.EmpAge).HasColumnName("empAge");

                entity.Property(e => e.EmpName)
                    .IsRequired()
                    .HasColumnName("empName")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.RegisterNum).HasColumnName("registerNum");
            });

            modelBuilder.Entity<Games>(entity =>
            {
                entity.HasKey(e => e.ProductId);

                entity.Property(e => e.ProductId)
                    .HasColumnName("productId")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.AgeRating)
                    .HasColumnName("ageRating")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.GameGenre)
                    .HasColumnName("gameGenre")
                    .HasMaxLength(50)
                    .IsFixedLength();

                entity.Property(e => e.Price)
                    .HasColumnName("price")
                    .HasColumnType("decimal(16, 2)");

                entity.Property(e => e.Rating)
                    .HasColumnName("rating")
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Payments>(entity =>
            {
                entity.HasKey(e => e.CardNum);

                entity.Property(e => e.CardNum)
                    .HasColumnName("cardNum")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsFixedLength();

                entity.Property(e => e.DatePurchased).HasColumnType("datetime");

                entity.Property(e => e.PaymentMethod)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.ProductId)
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Store>(entity =>
            {
                entity.HasKey(e => e.StoreNum);

                entity.Property(e => e.StoreNum)
                    .HasColumnName("storeNum")
                    .ValueGeneratedNever();

                entity.Property(e => e.Manager)
                    .HasMaxLength(20)
                    .IsFixedLength();

                entity.Property(e => e.StoreCity)
                    .HasColumnName("storeCity")
                    .HasMaxLength(50)
                    .IsFixedLength();

                entity.Property(e => e.StoreProvince)
                    .HasColumnName("storeProvince")
                    .HasMaxLength(50)
                    .IsFixedLength();

                entity.Property(e => e.StoreStreet)
                    .HasColumnName("storeStreet")
                    .HasMaxLength(50)
                    .IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
