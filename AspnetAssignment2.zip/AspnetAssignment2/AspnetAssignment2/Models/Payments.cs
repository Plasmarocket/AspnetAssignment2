﻿using System;
using System.Collections.Generic;

namespace AspnetAssignment2.Models
{
    public partial class Payments
    {
        public string ProductId { get; set; }
        public string CustomerName { get; set; }
        public string CardNum { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime? DatePurchased { get; set; }
    }
}
