﻿using System;
using System.Collections.Generic;

namespace AspnetAssignment2.Models
{
    public partial class Customer
    {
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }
        public int? CardNum { get; set; }
        public string BillingAddress { get; set; }
        public string EmpNum { get; set; }
    }
}
