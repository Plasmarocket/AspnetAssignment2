﻿using System;
using System.Collections.Generic;

namespace AspnetAssignment2.Models
{
    public partial class Games
    {
        public string ProductId { get; set; }
        public string GameGenre { get; set; }
        public string AgeRating { get; set; }
        public decimal? Price { get; set; }
        public string Rating { get; set; }
    }
}
