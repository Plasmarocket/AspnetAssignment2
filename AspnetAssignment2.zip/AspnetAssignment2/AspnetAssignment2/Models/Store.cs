﻿using System;
using System.Collections.Generic;

namespace AspnetAssignment2.Models
{
    public partial class Store
    {
        public int StoreNum { get; set; }
        public string StoreProvince { get; set; }
        public string StoreCity { get; set; }
        public string StoreStreet { get; set; }
        public string Manager { get; set; }
    }
}
