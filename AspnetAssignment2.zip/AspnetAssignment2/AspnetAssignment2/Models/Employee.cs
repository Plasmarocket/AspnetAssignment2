﻿using System;
using System.Collections.Generic;

namespace AspnetAssignment2.Models
{
    public partial class Employee
    {
        public string EmpName { get; set; }
        public int EmpNum { get; set; }
        public int? EmpAge { get; set; }
        public DateTime? CheckoutDate { get; set; }
        public int? RegisterNum { get; set; }
    }
}
